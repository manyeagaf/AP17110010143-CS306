//single line comment

/*multi line
comment*/

int main()
{

printf("Hello world");

}