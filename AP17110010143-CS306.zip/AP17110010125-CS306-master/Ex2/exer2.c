void main(){

int a,b,c;
a = 12;
b = 13;
c = 11;

int d= a+b*c;

printf("%d",&d);

}
